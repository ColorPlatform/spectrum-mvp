#!/usr/bin/env bash

SYS_CHANNEL='testchainid'
ORDERER_GENSIS=orderer.genesis.block
ORDERER_GENSIS_PROFILE=TwoOrgsOrdererGenesis
APP_CHANNEL="businesschannel"
APP_CHANNEL_PROFILE=TwoOrgsChannel
UPDATE_ANCHOR_ORG1_TX=Org1MSPanchors.tx
UPDATE_ANCHOR_ORG2_TX=Org2MSPanchors.tx
CHANNEL_ARTIFACTS=channel-artifacts
ORG1MSP="Org1MSP"
ORG2MSP="Org2MSP"
