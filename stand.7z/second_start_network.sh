export PATH=$PWD/fabric-samples/bin:$PATH
cd fabric-samples/first-network
./byfn.sh up
