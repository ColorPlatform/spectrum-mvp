curl -sSL http://bit.ly/2ysbOFE | bash -s 1.3.0
#export PATH=$PWD/fabric-samples/bin:$PATH
#cd fabric-samples/first-network
#./byfn.sh generate
#./byfn.sh up
